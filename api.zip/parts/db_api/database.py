# from gino import Gino
# from gino.schema import GinoSchemaVisitor
# from data.config import POSTGRES_URI
from data.config import mongodbip, mongodbport, mongodb_name

import pymongo
from pymongo import MongoClient
from pymongo.server_api import ServerApi


# db = Gino()
# MongoDB
# client = MongoClient(mongodbip, mongodbport)
# db = client[mongodb_name]


# Документация
# http://gino.fantix.pro/en/latest/tutorials/tutorial.html

def init_db():
    # Устанавливаем связь с базой данных
    # await db.set_bind(POSTGRES_URI)
    # db.gino: GinoSchemaVisitor
    #
    # # Создаем таблицы
    # # await db.gino.drop_all()
    # await db.gino.create_all()

    # def get_mongodb_connection(host: str,
    #                            port: Union[str, int],
    #                            user: str,
    #                            password: str,
    #                            database: str,
    #                            auth_database: str) -> Database:
        """
        Creates a mongoDB connection to the db to sync from
        Returns: Database instance with established connection

        """
        client = pymongo.MongoClient(mongodbip, mongodbport)


        # client = pymongo.MongoClient(
            # "mongodb+srv://gffdhfdghfghg45445:LNSaOP9hWQkfAzuG@cluster0.6oksp.mongodb.net/",
            # server_api=ServerApi('1'))

        db = client[mongodb_name]
        return db



db = init_db()

resource_table = db['res']

