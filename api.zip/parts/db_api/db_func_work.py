import pprint
from datetime import datetime, timedelta

from parts.db_api.database import resource_table
from bson.objectid import ObjectId


async def getOneData():

    # data = resource_table.find().limit(1)
    data = resource_table.aggregate([{ '$sample': { 'size': 1 }}])

    return data


async def delOne(id_str):
    resource_table.delete_one({'_id': ObjectId(id_str)})
    return True