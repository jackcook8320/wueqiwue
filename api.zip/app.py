import json

from data import config

import asyncio
import base64
import os
import pprint

import hypercorn.asyncio
from quart import Quart, render_template_string, request

from bson import json_util

from bson.json_util import dumps

from parts.db_api.db_func_work import getOneData, delOne


def get_env(name, message):
    if name in os.environ:
        return os.environ[name]
    return input(message)


# Quart app
app = Quart(__name__)
app.secret_key = 'CHANGE THIS TO SOMETHING SECRET'


# Connect the client before we start serving with Quart
@app.before_serving
async def startup():
    # print('kuku');

    try:
        print('kuku2');

        # print('kuku3');
    except Exception as ex:
        print(ex)
        print()


# After we're done serving (near shutdown), clean up the client
@app.after_serving
async def cleanup():
    print('kuku(near shutdown)');


@app.route('/api/test', methods=['GET'])
async def test_data():
    # We want to update the global phone variable to remember it
    print('куку страничка')
    data_json = await getOneData()
    # pprint.pprint(data_json)

    # pprint.pprint(type(data_json))

    list_cur = list(data_json)

    cookies_all_str = ""
    cookies_list_str = list_cur[0]['3']


    # pprint.pprint('==========')
    # pprint.pprint(type(cookies_list_str))
    # pprint.pprint(cookies_list_str)
    # pprint.pprint('======')

    if cookies_list_str != '':
        cookies_list = json.loads(cookies_list_str)
        # pprint.pprint(type(cookies_list))


        for one_c in cookies_list:
            # pprint.pprint(one_c)
            # pprint.pprint('======one_c')
            name = one_c['name']
            value = one_c['value']
            curr_str_cookie = f'{name}={value}; '
            cookies_all_str += curr_str_cookie

    header_all_str = "";
    headers_list_str = list_cur[0]['2']
    if headers_list_str != '':

        headers_list = json.loads(headers_list_str)



        for one_h in headers_list:

            name = one_h[0]
            value = one_h[1]
            curr_str_header = f'{name}: {value}\n'
            header_all_str += curr_str_header

        if cookies_list_str != '':
            header_all_str += f"Cookie: {cookies_all_str}"
    else:

        if cookies_list_str != '':
            header_all_str += f"Cookie: {cookies_all_str}"


    json_data = dumps(list_cur)

    # pprint.pprint(type(json_data))

    pprint.pprint(header_all_str)

    header_all_str = f'<pre>{header_all_str}</pre>'
    # pprint.pprint(type(cookies_all_str))

    return header_all_str

@app.route('/api/del', methods=['GET'])
async def test_del():
    id_input = request.args.get("del_id")
    if id_input != None:
        await delOne(id_input)
        return 'del ok'

    else:
        return 'no id passed, err'


async def main():
    config = hypercorn.Config()
    config.bind = ["localhost:8080"]  # As an example configuration setting

    await hypercorn.asyncio.serve(app, config)


# By default, `Quart.run` uses `asyncio.run()`, which creates a new asyncio
# event loop. Instead, we use `asyncio.run()` manually in order to make this
# explicit, as the client cannot be "transferred" between loops while
# connected due to the need to schedule work within an event loop.
#
# In essence one needs to be careful to avoid mixing event loops, but this is
# simple, as `asyncio.run` is generally only used in the entry-point of the
# program.
#
# To run Quart inside `async def`, we must use `hypercorn.asyncio.serve()`
# directly.
#
# This example creates a global client outside of Quart handlers.
# If you create the client inside the handlers (common case), you
# won't have to worry about any of this, but it's still good to be
# explicit about the event loop.
if __name__ == '__main__':
    # asyncio.run(main())
    asyncio.get_event_loop().run_until_complete(main())
