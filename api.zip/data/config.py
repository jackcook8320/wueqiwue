mongodbip = '127.0.0.1';
mongodbport = 27017;
mongodb_name = '1';